const express = require("express");
const fs = require("fs");
const path = require("path");
const uniqid = require("uniqid");
const router = express.Router();
const myExamFilePath = path.join(__dirname, "exams.json");
const myQuestionsilePath = path.join(__dirname, "questions.json");
const readFile = (fileName) => {
  const buffer = fs.readFileSync(path.join(__dirname, fileName));
  const fileContent = buffer.toString();
  return JSON.parse(fileContent);
};

router.get("/", (req, res) => {
  try{
    const questionsAsArray = readFile("questions.json");
    res.send(questionsAsArray);
  }catch(err){
    next(err)
    console.log(err)
  }
  });
  router.get("/getExam/:id", (req, res) => {
    try{
    const examsAsArray = readFile("exams.json");
    const exam = examsAsArray.filter(x => x.id === req.params.id)
    res.send(exam)
    }catch(err){
      next(err)
      console.log(err)
    }
  });
 router.put("/updateExam/:id",(req,res) =>{
   try{
  const examsAsArray = readFile("exams.json");
   const indexOfExam = examsAsArray.findIndex(x=> x.id === req.params.id)
   examsAsArray[indexOfExam] = {...examsAsArray[indexOfExam], ...req.body}
   fs.writeFileSync(myExamFilePath, JSON.stringify(examsAsArray));
    res.send(newExam);
  }catch(err){
    console.log(err)
  }
 })
  function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
  }
router.post("/",(req,res,next) => {
  try{
    const examsAsArray = readFile("exams.json");
    const newExam = req.body
    newExam.id = uniqid()
    newExam.examDate = new Date()
    newExam.isFinised = false
    newExam.score = 0
    const arrayOfQuestions = []
    const questionsAsArray = readFile("questions.json");
    for (let index = 0; index < 5; index++) {
      const element = getRandomInt(24)
       arrayOfQuestions[index] = questionsAsArray[element]
    }
    arrayOfQuestions.forEach(x=> x.answers.forEach(y=>y.isCorrect = false))
    newExam.randomQs = arrayOfQuestions
    examsAsArray.push(newExam)
    fs.writeFileSync(myExamFilePath, JSON.stringify(examsAsArray));
    res.status(201).send(newExam);
  }catch(err){
    next(err)
    console.log(err)
  }
})
router.post("/addQuestion",(req,res,next) => {
  try{
    const questionsAsArray = readFile("questions.json");
    const newQuestion = req.body
    questionsAsArray.push(newQuestion)
    fs.writeFileSync(myQuestionsilePath, JSON.stringify(questionsAsArray));
    res.status(201).send(newQuestion);
  }catch(err){
    next(err)
    console.log(err)
  }
})

router.delete("/deleteQuestion/:name",(req,res,next) => {
  try{
    const questionsAsArray = readFile("questions.json");
    questionsAsArray = questionsAsArray.filter(x => x.name !== req.params.name)
    fs.writeFileSync(myQuestionsilePath, JSON.stringify(questionsAsArray));
    res.status(201).send("Deleted");
  }catch(err){
    next(err)
    console.log(err)
  }
})
router.put("/updateQuestion/:name",(req,res,next) => {
  try{
    const questionsAsArray = readFile("questions.json");
    const index = questionsAsArray.findIndex(x => x.name === req.params.name)
    questionsAsArray[index] = req.body
    fs.writeFileSync(myQuestionsilePath, JSON.stringify(questionsAsArray));
    res.status(201).send("Deleted");
  }catch(err){
    next(err)
    console.log(err)
  }
})

  module.exports = router;